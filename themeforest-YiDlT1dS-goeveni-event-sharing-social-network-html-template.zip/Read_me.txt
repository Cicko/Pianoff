Goeveni is a HTML5 & CSS3 responsive Bootstrap 4 template created for Plateform but also can be used for generalised website. Goeveni is evaluated as my most unique event sharing social networking HTML template for online event sharing with clean and modern design. Goeveni will be a subtle and smart choice for user. Our reputation system will make it easy to find the perfect event for you and posted by you. It�s the simplest and safest way to get event sharing and buy tickets done online. There is no doubt that Goeveni will make your events look more impressive and attractive to viewers. Designed on grid system, your site will look sharp on all screens.. Our package includes 47 well-organized HTML files.

Features :-

- 47 Html Files
- Fully Boostrap 4
- 01 Homepages unique
- User Timeline activity layout
- 01 Event Post layout style
- Checkout
- Discussion page
- Account setting pages
- Profile Pages
- Partner With Us For Restaurants
- Add New Event
- Messages Page
- Weather Page
- Search Page
- Login and Register
- Creative and unique design
- Designed on 1170px Grid System
- Pixel perfect
- Free Google Fonts
- Free Font Based Icons
- Free Svg Based Icons


Fonts used :-

Roboto: https://fonts.google.com/specimen/Roboto

Icon Used :-

FontAwesome: https://fontawesome.com/
Flaticons: https://www.flaticon.com/

IMPORTANT!!! All Images are from different resources and they are not included to Html files.


Pixel Dimensions: 1920x3500

Tags: concert, conference, conference template, congress, convocation, course, event, event website, exhibition, meeting, Meetup, seminar, speaker, webinar, workshop